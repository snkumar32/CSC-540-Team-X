package wolfPub.ui;

public class MainMenu {
}
