package wolfPub.config;

public class Variables {


        private final String url = "jdbc:mariadb://classdb2.csc.ncsu.edu:3306/skumar32";

        private final String user = "skumar32";

        private final String password = "ncsu123";

        public String getUrl() {
            return "jdbc:mariadb://classdb2.csc.ncsu.edu:3306/skumar32";
        }

        public String getUser() {
            return "skumar32";
        }

        public String getPassword() {
            return "ncsu123";
        }
    }





